package classes;
 
 import java.lang.*;

public class ImportedProduct extends Product
{
	private String countryName;
	
	public void setCountryName(String countryName)
	{
		this.countryName = countryname;
	}
	public int getCountryName()
	{
		return CountryName
	}
	public void showInfo()
	{
		System.out.println("Pid: "+getPid());
		System.out.println("Name: "+getName());
		System.out.println("AvailableQuantity: "+getAvailablequantity());
		System.out.println("Price: "+getPrice());
		System.out.println("CountryName: "+ CountryName);
		System.out.println();
	}
}
package interfaces;

import java.lang.*;



public interface IQuantity

{
	boolean addQuantity(int amount);
	boolean selfQuantity(int amount);
}
package classes; 
import java.lang.*;
import interfaces.*;

public abstract class Product implements IQuantity
{
	private string pid;
	private string name;
	private int availableQuantity;
	private double price;
	
	public void setPid(String pid){this.pid = pid;}
	public void setName(String name){this.name = name;}
	public void setAvailableQuantity(int quantity){this.quantity=quantity;}
	public void setPrice(double price){this.price=price;}
	
	public String getPid(){return pid;}
	public String getName(){return name;}
	public int getAvailableQuantity(){return availablequantity;}
	public double getPrice(){return price;}
	
	public abstract void showInfo();
	
	public boolean addQuantity(int amount)
	{
		if(amount>0)
		{
			System.out.println("Previous Balance: "+ balance);
			System.out.println("Add Amount: "+ amount);
			balance += amount;
			//balance = balance + amount;
			System.out.println("Current Balance: "+ balance);
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean sellQuantity(int amount)
	{
		if(amount>0 && amount<=balance)
		{
			System.out.println("Previous Balance:	"+ balance);
			System.out.println("sellQuantity Amount:	"+ amount);
			balance -= amount;
			//balance = balance - amount;
			System.out.println("Current Balance:	"+ balance);
			return true;
		}
		else
		{
			return false;
		}
	}	
}
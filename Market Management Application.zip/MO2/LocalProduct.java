package classes;
import java.lang.*;

public class LocalProduct extends Product
{
	private double discountRate;
	
	public void setdiscountRate(double discountRate)
	{
		this.discountRate = discountRate;
	}
	public double getdiscountRate()
	{
		return interestRate;
	}
	public void showInfo()
	{
		System.out.println("Pid: "+getPid());
		System.out.println("Name: "+getName());
		System.out.println("AvailableQuantity: "+getAvailablequantity());
		System.out.println("Price: "+getPrice());
		System.out.println("Discount Rate: "+interestRate);
		System.out.println();
	}
}
package interfaces;

import classes.shop;
public interface ShopOperations
{
	boolean insertShop(Shop s);
	boolean removeShop(Shop s);
	Customer searchShop(string sid);
	void showAllShops();
}
package interfaces;
import java.lang.*;
import classes.Product;


public interface ProductOperation
{
	boolean insertProduct(Product p);
	boolean removeproduct(product p);
	Account searchProduct(string pid);
	void showAllProducts();
}